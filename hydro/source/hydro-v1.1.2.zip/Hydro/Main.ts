import Parser from "./Frontend/Parser"
import { Environment } from "./Runtime/Environment"
import { Evaluate } from "./Runtime/Interpreter"
import * as FileSystem from "fs"
import * as Path from "path"

const prompt = require("prompt-sync")()

Run(process.argv[2])

export async function Run(path?: string): Promise<void> {
    const parser = new Parser()
    const environment = new Environment()

    if (path) {
        console.log(`Running file ${Path.resolve(process.argv[2])}`)
        const input = FileSystem.readFileSync(path, "utf-8")
        const program = parser.ProduceAST(input)
        const result = Evaluate(program, environment)
    } else {
        console.log("\nHydro Repl v1.0\nMade by HyperKNF, all rights reserved\nCopyrighted under HyperKNF.com\nTo exit, type \"exit\"")
        while (true) {
            const input = prompt("> ")
            
            if (!input || input.includes("exit")) break

            const program = parser.ProduceAST(input)
            const result = Evaluate(program, environment)
        }
    }

    return
}