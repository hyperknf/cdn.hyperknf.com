"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Parameter = void 0;
var Parameter = /** @class */ (function () {
    function Parameter(name, type) {
        this.Name = name;
        this.Type = type;
    }
    return Parameter;
}());
exports.Parameter = Parameter;
